## CPP_SnakeGame

### Create a SnakeGame with ncurses : ncurses를 사용하여 스네이크 게임 만들기
### Period : 2020/05/30 - 2020/06/21
