// 실제 게임을 돌릴 코드

#include <iostream>
#include <ncurses.h>
#include "SnakeGame.h"

using namespace std;

int main(){
  SnakeGame S;
  S.Start();
  return 0;
}
